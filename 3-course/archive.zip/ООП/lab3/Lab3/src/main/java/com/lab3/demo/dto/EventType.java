package com.lab3.demo.dto;

public enum EventType {
    CREATE, UPDATE, DELETE
}
