package com.lab3.demo.exception;

public class CardStateException extends RuntimeException {
    public CardStateException(String message) {
        super(message);
    }
}