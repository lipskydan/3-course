package base_package;

public class Main {
    public static void main(String[] args) {
        Line line = new Line(130, 10);
        line.start();
    }
}