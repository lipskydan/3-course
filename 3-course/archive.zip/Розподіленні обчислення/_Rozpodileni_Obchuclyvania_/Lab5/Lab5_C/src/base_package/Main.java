package base_package;

public class Main {

    public static void main(String[] args) {
        ThreadController controller = new ThreadController();
        controller.beginCount();
    }
}
