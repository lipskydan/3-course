package base_package;

class Table {
    boolean tabaco  = false;
    boolean paper   = false;
    boolean matches = false;
}
