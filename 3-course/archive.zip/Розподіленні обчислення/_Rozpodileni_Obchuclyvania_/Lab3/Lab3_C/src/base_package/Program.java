package base_package;

public class Program {

    public static void main(String[] args) {
        Action action = new Action();
        action.letsSmoke();
    }
    
}
