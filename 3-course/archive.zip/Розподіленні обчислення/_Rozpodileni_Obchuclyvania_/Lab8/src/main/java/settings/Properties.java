package settings;

public class Properties {
    public static final String RESULT_PATH = "result.txt";
    public static final String HTML_PATH = "table.html";

    public static final int MAX_VALUE = 16;
}
