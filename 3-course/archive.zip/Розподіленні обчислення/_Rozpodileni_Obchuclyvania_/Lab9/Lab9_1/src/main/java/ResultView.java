public class ResultView {
}
