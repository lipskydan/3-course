package sample;

public class OperationCodes {
    public static int GET_ALL = 0;
    public static int UPDATE_AIRCOMPANY = 1;
    public static int UPDATE_FLIGHT = 2;
    public static int ADD_AIRCOMPANY = 3;
    public static int ADD_FLIGHT = 4;
    public static int DELETE_AIRCOMPANY = 5;
    public static int DELETE_FLIGHT = 6;
}
