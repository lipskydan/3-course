package com.company;

public class Country {
    public int code; // Уникальный код страны
    public String name; // Название страны

    public Country(int inCode, String inName) {
        code = inCode;
        name = inName;
    }
}
