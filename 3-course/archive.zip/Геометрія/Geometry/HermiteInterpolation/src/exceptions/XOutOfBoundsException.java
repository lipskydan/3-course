package exceptions;

public class XOutOfBoundsException extends Exception {

    public XOutOfBoundsException() {

    }

    public XOutOfBoundsException(String message) {
        super(message);
    }
}
